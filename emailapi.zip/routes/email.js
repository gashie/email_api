const express = require('express');

const router = express.Router();

const { AccountSetupEmail, GodsEye,CustomerUpdate,OTP } = require('../controllers/Email');
//routes
router.route('/').post(AccountSetupEmail);
router.route('/birdsalert').post(GodsEye);
router.route('/csupdate').post(CustomerUpdate);
router.route('/otp').post(OTP);

module.exports = router;
